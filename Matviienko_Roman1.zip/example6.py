now = int(input('Сколько километров ты сегодня пробежал? >>> '))
future = int(input('Сколько хочешь пробегать километров? >>> '))
counter = 0
while now < future:
    now = now * 0.1 + now
    counter += 1
print(f'Ты пробежишь {future} километров через {counter} дней')