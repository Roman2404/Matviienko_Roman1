time = int(input('Введите количество времени в секундах >>>'))
sek = time % 60
hour = time // 3600
min = (time - (hour * 3600)) // 60
print(hour, ':', min, ':', sek, sep='')