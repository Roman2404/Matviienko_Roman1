name = input('Как Вас зовут? >>>')
city = input('В каком городе Вы живете? >>>')
print(city, '- отличный город,', name)
print('Хорошего дня,', name)
