num = int(input('Введите число от 0 до 10 >>>'))
num2 = num * 10 + num
num3 = num * 100 + num2
print(num + num2 + num3)
print('Хорошего дня!')